export interface Story {
  title: string
  summary: string[]
  why: string
  publishedAt: string
  category: string
  image: string
  tags: string[]
}

export const featuredStory = {
  title: "Next.js 15 Revolutionizes Full-Stack Development",
  description:
    "The latest Next.js release introduces groundbreaking features including React Server Components 2.0, enhanced App Router, and revolutionary caching mechanisms that will transform how we build modern web applications.",
  category: "Framework Update",
  publishedAt: "2 hours ago",
  image: "/placeholder.svg?height=600&width=1200",
  tags: ["Next.js", "React", "Full-Stack", "Performance", "SSR"],
}

export const contentSections = [
  {
    title: "🔥 Trending This Week",
    stories: [
      {
        title: "React 19 Beta: Concurrent Features Go Mainstream",
        summary: [
          "New concurrent rendering capabilities for better UX",
          "Enhanced Suspense boundaries with error recovery",
          "Automatic batching improvements across all updates",
        ],
        why: "These features will significantly improve app performance and user experience in production environments.",
        publishedAt: "4 hours ago",
        category: "Framework",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["React", "Performance", "Concurrent", "Beta"],
      },
      {
        title: "TypeScript 5.3: Decorators and Import Attributes",
        summary: [
          "Stage 3 decorators support with full metadata reflection",
          "Import attributes for JSON and CSS modules",
          "Enhanced type inference for complex generic scenarios",
        ],
        why: "These additions make TypeScript more powerful for enterprise applications and modern web development patterns.",
        publishedAt: "6 hours ago",
        category: "Language",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["TypeScript", "Decorators", "ES2024", "Types"],
      },
      {
        title: "Tailwind CSS 4.0 Alpha: CSS-in-JS Revolution",
        summary: [
          "Zero-runtime CSS-in-JS with compile-time optimization",
          "New container queries and advanced grid utilities",
          "Built-in design system tokens and theme management",
        ],
        why: "This represents a major shift in how we approach styling in modern web applications.",
        publishedAt: "8 hours ago",
        category: "CSS Framework",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Tailwind", "CSS", "Performance", "DX"],
      },
      {
        title: "Vite 5.0: Lightning Fast Build Tool Evolution",
        summary: [
          "50% faster cold start times with new bundling strategy",
          "Enhanced HMR with selective module replacement",
          "Built-in support for Web Workers and Service Workers",
        ],
        why: "Faster development cycles mean increased productivity and better developer experience.",
        publishedAt: "12 hours ago",
        category: "Build Tool",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Vite", "Build", "Performance", "DX"],
      },
    ],
  },
  {
    title: "🚀 New Releases",
    stories: [
      {
        title: "Astro 4.0: The Content-First Web Framework",
        summary: [
          "New View Transitions API for smooth page navigation",
          "Enhanced content collections with type safety",
          "Zero-JS by default with selective hydration",
        ],
        why: "Perfect for content-heavy sites that need excellent performance and SEO.",
        publishedAt: "1 day ago",
        category: "Framework",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Astro", "Content", "Performance", "SSG"],
      },
      {
        title: "Prisma 6: Database ORM Gets AI-Powered",
        summary: [
          "AI-assisted query optimization and suggestions",
          "Enhanced type safety with runtime validation",
          "New migration system with rollback capabilities",
        ],
        why: "AI-powered database interactions will revolutionize how developers work with data.",
        publishedAt: "1 day ago",
        category: "Database",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Prisma", "Database", "AI", "ORM"],
      },
      {
        title: "Supabase Edge Functions: Serverless at the Edge",
        summary: [
          "Global edge deployment with sub-50ms latency",
          "Built-in authentication and database integration",
          "TypeScript-first development experience",
        ],
        why: "Edge computing brings backend logic closer to users for better performance.",
        publishedAt: "2 days ago",
        category: "Backend",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Supabase", "Edge", "Serverless", "TypeScript"],
      },
      {
        title: "Shadcn/UI 2.0: Component Library Revolution",
        summary: [
          "New theming system with CSS variables",
          "Enhanced accessibility with ARIA compliance",
          "Headless components with full customization",
        ],
        why: "Better component libraries accelerate development while maintaining design consistency.",
        publishedAt: "2 days ago",
        category: "UI Library",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Shadcn", "Components", "Accessibility", "Design"],
      },
    ],
  },
  {
    title: "💡 Skills to Master",
    stories: [
      {
        title: "Master Server Components: The Future of React",
        summary: [
          "Understanding the server-client boundary in modern React",
          "Optimizing data fetching with server components",
          "Building hybrid applications with selective hydration",
        ],
        why: "Server Components are becoming the standard for high-performance React applications.",
        publishedAt: "3 days ago",
        category: "Skill",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["React", "Server Components", "Performance", "Architecture"],
      },
      {
        title: "Advanced TypeScript Patterns for 2024",
        summary: [
          "Template literal types for better API design",
          "Conditional types and mapped type utilities",
          "Brand types for runtime safety guarantees",
        ],
        why: "Advanced TypeScript patterns help build more robust and maintainable applications.",
        publishedAt: "3 days ago",
        category: "Skill",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["TypeScript", "Patterns", "Advanced", "Types"],
      },
      {
        title: "Web Performance Optimization in 2024",
        summary: [
          "Core Web Vitals optimization strategies",
          "Advanced caching patterns and CDN usage",
          "Bundle splitting and code optimization techniques",
        ],
        why: "Performance directly impacts user experience and business metrics.",
        publishedAt: "4 days ago",
        category: "Skill",
        image: "/placeholder.svg?height=300&width=400",
        tags: ["Performance", "Web Vitals", "Optimization", "UX"],
      },
    ],
  },
]

export const dummyStories: Story[] = []
