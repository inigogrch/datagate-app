"use client"

import { Calendar, TrendingUp, ExternalLink } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"

interface StoryCardProps {
  title: string
  summary?: string[]
  why: string
  publishedAt: string
  category: string
  image: string
  tags?: string[]
}

export default function StoryCard({
  title,
  summary = [],
  why,
  publishedAt,
  category,
  image,
  tags = [],
}: StoryCardProps) {
  const handleCardClick = () => {
    console.log(`Clicked on: ${title}`)
  }

  return (
    <Card className="w-80 h-[500px] bg-gray-900 border-gray-800 rounded-lg overflow-hidden hover:scale-105 transition-all duration-300 cursor-pointer group flex flex-col">
      <div onClick={handleCardClick}>
        {/* Image */}
        <div className="relative h-48 overflow-hidden">
          <img
            src={image || "/placeholder.svg"}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <Badge className="absolute top-3 left-3 bg-red-600 text-white">{category}</Badge>
        </div>

        {/* Content */}
        <div className="p-6 flex-1 flex flex-col">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-400">{publishedAt}</span>
            </div>

            <h3 className="text-lg font-semibold text-white mb-3 line-clamp-2 group-hover:text-red-400 transition-colors">
              {title}
            </h3>

            <div className="mb-4">
              <ul className="space-y-1">
                {summary.slice(0, 2).map((item, index) => (
                  <li key={index} className="text-sm text-gray-300 flex items-start gap-2">
                    <span className="text-red-500 mt-1.5 text-xs">•</span>
                    <span className="line-clamp-1">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-4">
              <p className="text-xs text-gray-400 line-clamp-2">
                <TrendingUp className="h-3 w-3 inline mr-1" />
                {why}
              </p>
            </div>

            <div className="flex flex-wrap gap-1 mb-4">
              {tags.slice(0, 3).map((tag, index) => (
                <Badge key={index} variant="outline" className="text-xs border-gray-600 text-gray-400">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>

          <Button variant="ghost" size="sm" className="w-full text-gray-300 hover:text-white hover:bg-gray-800">
            <ExternalLink className="h-4 w-4 mr-2" />
            Read More
          </Button>
        </div>
      </div>
    </Card>
  )
}
