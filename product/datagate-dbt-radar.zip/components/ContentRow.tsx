"use client"

import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import StoryCard from "./StoryCard"
import { useRef } from "react"

interface ContentRowProps {
  title: string
  stories: Array<{
    title: string
    summary: string[]
    why: string
    publishedAt: string
    category: string
    image: string
    tags: string[]
  }>
}

export default function ContentRow({ title, stories }: ContentRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 3 * 320 + 3 * 16 // 3 cards + gaps
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  return (
    <div className="mb-12 mt-8">
      <div className="flex items-center justify-between mb-6 px-4 md:px-8 mt-6">
        <h2 className="text-2xl font-bold text-white">{title}</h2>
      </div>

      <div ref={scrollRef} className="flex gap-4 overflow-x-auto scrollbar-hide px-4 md:px-8 pb-4">
        {stories.map((story, index) => (
          <div key={index} className="flex-none">
            <StoryCard {...story} />
          </div>
        ))}
      </div>

      <div className="flex justify-center gap-2 mt-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => scroll("left")}
          className="text-gray-400 hover:text-white hover:bg-gray-800 bg-gray-900 border border-gray-700"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => scroll("right")}
          className="text-gray-400 hover:text-white hover:bg-gray-800 bg-gray-900 border border-gray-700"
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>
    </div>
  )
}
