import Sidebar from "@/components/Sidebar"
import TopNav from "@/components/TopNav"
import ContentRow from "@/components/ContentRow"
import { dummyStories, contentSections } from "@/lib/dummyData"

export default function FeedPage() {
  // TODO: Replace with actual API hooks
  const stories = dummyStories
  const sections = contentSections

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-[240px_1fr] bg-neutral-900">
      <Sidebar />

      <div className="flex flex-col">
        <TopNav />

        <main className="flex-1 p-6 pt-20">
          {sections.map((section, index) => (
            <ContentRow key={index} title={section.title} stories={section.stories} />
          ))}
        </main>
      </div>
    </div>
  )
}
